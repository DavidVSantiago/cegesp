/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_cpt_documents`; */
/* PRE_TABLE_NAME: `1761862779_wp_cpt_documents`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1761862779_wp_cpt_documents` ( `id` bigint(20) NOT NULL AUTO_INCREMENT, `post_id` bigint(20) NOT NULL, `palavra_chave` varchar(255) NOT NULL, `esfera` varchar(255) NOT NULL, `poder` varchar(255) NOT NULL, `etapa` varchar(255) NOT NULL, `indicador` varchar(255) NOT NULL, `ano` int(4) NOT NULL, `file_id` bigint(20) NOT NULL, `file_url` text NOT NULL, PRIMARY KEY (`id`), UNIQUE KEY `post_id` (`post_id`), UNIQUE KEY `file_id` (`file_id`), KEY `post_id_idx` (`post_id`)) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1761862779_wp_cpt_documents` (`id`, `post_id`, `palavra_chave`, `esfera`, `poder`, `etapa`, `indicador`, `ano`, `file_id`, `file_url`) VALUES (3,92,'vacina','federal','poder_executivo','planejamento','loa',2003,92,'https://cegesp.b-cdn.net/documents/92/dumb_teste.pdf'),(4,93,'vacina','federal','poder_executivo','planejamento','loa',2024,93,'https://cegesp.b-cdn.net/documents/93/dumb_teste.pdf'),(5,94,'vacina','federal','poder_executivo','planejamento','loa',2006,94,'https://cegesp.b-cdn.net/documents/94/dumb_teste.pdf'),(6,95,'vacina','federal','poder_executivo','planejamento','loa',2008,95,'https://cegesp.b-cdn.net/documents/95/dumb_teste.pdf');
